# Copyright © SixtyFPS GmbH <info@slint.dev>
# SPDX-License-Identifier: LicenseRef-Slint-commercial

from __future__ import annotations
import contextlib
import subprocess
import typing
import socket
import os
import select
from .slint_systest_pb2 import (
    RequestWindowListMessage,
    RequestToAUT,
    AUTResponse,
    RequestFindElementsById,
    RequestWindowProperties,
    WindowPropertiesResponse,
    Handle,
    RequestElementProperties,
    ElementPropertiesResponse,
    RequestInvokeElementAccessibilityAction,
    ElementAccessibilityAction,
    RequestSetElementAccessibleValue,
    AccessibleRole as ProtoAccessibleRole,
    LayoutKind as ProtoLayoutKind,
    RequestTakeSnapshot,
    ClickAction,
    RequestElementClick,
    PointerEventButton as ProtoPointerEventButton,
)
from .slint_systest_pb2 import (
    PointerPressEvent as ProtoPointerPressEvent,
    PointerReleaseEvent as ProtoPointerReleaseEvent,
    PointerMoveEvent as ProtoPointerMoveEvent,
    PointerScrolledEvent as ProtoPointerScrolledEvent,
    PointerExitedEvent as ProtoPointerExitedEvent,
    KeyPressedEvent as ProtoKeyPressedEvent,
    KeyPressRepeatedEvent as ProtoKeyPressRepeatedEvent,
    KeyReleasedEvent as ProtoKeyReleasedEvent,
    WindowEvent as ProtoWindowEvent,
    RequestDispatchWindowEvent,
    LogicalPosition as ProtoLogicalPosition,
)
from .slint_systest_pb2 import (
    ElementQueryInstruction as ProtoElementQueryInstruction,
    RequestQueryElementDescendants,
)
import struct
import shlex
from dataclasses import dataclass
from enum import Enum


class PointerEventButton(Enum):
    """
    This enum describes the different types of buttons for a pointer event, typically on a mouse or a pencil.
    """

    Left = 0
    """The left button."""

    Right = 1
    """The right button."""

    Middle = 2
    """The middle button."""

    Back = 3
    """The back button."""

    Forward = 4
    """The forward button."""

    Other = 5
    """Any other button."""


def _convert_button(button: PointerEventButton) -> ProtoPointerEventButton:
    match button:
        case PointerEventButton.Left:
            return ProtoPointerEventButton.Left
        case PointerEventButton.Right:
            return ProtoPointerEventButton.Right
        case PointerEventButton.Middle:
            return ProtoPointerEventButton.Middle
        case PointerEventButton.Back:
            return ProtoPointerEventButton.Back
        case PointerEventButton.Forward:
            return ProtoPointerEventButton.Forward
        case PointerEventButton.Other:
            return ProtoPointerEventButton.Other
        case _ as unknown:
            raise RuntimeError("Unsupported button click requested")


class AccessibleRole(Enum):
    """
    This enum represents the different values for the `accessible-role` property, used to describe the
    role of an element in the context of assistive technology such as screen readers.
    """

    Unknown = 0
    """The element is not accessible and its role is not known."""

    Button = 1
    """The element is a button or behaves like one."""

    Checkbox = 2
    """The element is a checkbox or behaves like one."""

    Combobox = 3
    """The element is a combobox or behaves like one."""

    List = 4
    """The element is a list view or behaves like one."""

    Slider = 5
    """The element is a slider or behaves like one."""

    Spinbox = 6
    """The element is a spinbox or behaves like one."""

    Tab = 7
    """The element is a tab or behaves like one."""

    TabList = 8
    """The element is a tab bar in a tab widget."""

    Text = 9
    """The role for a Text element."""

    Table = 10
    """The element is a table view or behaves like one."""

    Tree = 11
    """The element is a tree view or behaves like one."""

    ProgressIndicator = 12
    """The element is a progress indicator or behaves like one."""

    TextInput = 13
    """The element is a text input field or behaves like one."""

    Switch = 14
    """The element is a switch or behaves like one."""

    ListItem = 15
    """The element is an item in a ListView."""

    TabPanel = 16
    """The element is a container for tab content."""

    Groupbox = 17
    """The element is a `GroupBox` or behaves like one."""

    Image = 18
    """The element is an `Image` or behaves like one. This is automatically applied to `Image` elements."""

    RadioButton = 19
    """The element is a radio button or behaves like one."""

    RadioGroup = 20
    """The element is a group of radio buttons."""

    Banner = 21
    """The element is a banner landmark, typically the page or site header."""

    Complementary = 22
    """The element is a complementary landmark holding supporting content."""

    ContentInfo = 23
    """The element is a content-info landmark, typically the page or site footer."""

    Form = 24
    """The element is a form landmark."""

    Main = 25
    """The element is the main-content landmark of the window."""

    Navigation = 26
    """The element is a navigation landmark holding navigational links."""

    Region = 27
    """The element is a generic region landmark."""

    Search = 28
    """The element is a search landmark."""

    @property
    def _proto_role(self) -> ProtoAccessibleRole:
        match self:
            case AccessibleRole.Unknown:
                return ProtoAccessibleRole.Unknown
            case AccessibleRole.Button:
                return ProtoAccessibleRole.Button
            case AccessibleRole.Checkbox:
                return ProtoAccessibleRole.Checkbox
            case AccessibleRole.Combobox:
                return ProtoAccessibleRole.Combobox
            case AccessibleRole.List:
                return ProtoAccessibleRole.List
            case AccessibleRole.Slider:
                return ProtoAccessibleRole.Slider
            case AccessibleRole.Spinbox:
                return ProtoAccessibleRole.Spinbox
            case AccessibleRole.Tab:
                return ProtoAccessibleRole.Tab
            case AccessibleRole.TabList:
                return ProtoAccessibleRole.TabList
            case AccessibleRole.Text:
                return ProtoAccessibleRole.Text
            case AccessibleRole.Table:
                return ProtoAccessibleRole.Table
            case AccessibleRole.Tree:
                return ProtoAccessibleRole.Tree
            case AccessibleRole.ProgressIndicator:
                return ProtoAccessibleRole.ProgressIndicator
            case AccessibleRole.TextInput:
                return ProtoAccessibleRole.TextInput
            case AccessibleRole.Switch:
                return ProtoAccessibleRole.Switch
            case AccessibleRole.ListItem:
                return ProtoAccessibleRole.ListItem
            case AccessibleRole.TabPanel:
                return ProtoAccessibleRole.TabPanel
            case AccessibleRole.Groupbox:
                return ProtoAccessibleRole.Groupbox
            case AccessibleRole.Image:
                return ProtoAccessibleRole.Image
            case AccessibleRole.RadioButton:
                return ProtoAccessibleRole.RadioButton
            case AccessibleRole.RadioGroup:
                return ProtoAccessibleRole.RadioGroup
            case AccessibleRole.Banner:
                return ProtoAccessibleRole.Banner
            case AccessibleRole.Complementary:
                return ProtoAccessibleRole.Complementary
            case AccessibleRole.ContentInfo:
                return ProtoAccessibleRole.ContentInfo
            case AccessibleRole.Form:
                return ProtoAccessibleRole.Form
            case AccessibleRole.Main:
                return ProtoAccessibleRole.Main
            case AccessibleRole.Navigation:
                return ProtoAccessibleRole.Navigation
            case AccessibleRole.Region:
                return ProtoAccessibleRole.Region
            case AccessibleRole.Search:
                return ProtoAccessibleRole.Search
            case _ as unknown:
                return ProtoAccessibleRole.Unknown


class LayoutKind(Enum):
    """
    Describes the kind of layout an element represents.

    Layout elements like ``HorizontalLayout`` or ``VerticalLayout`` are lowered to plain
    ``Rectangle`` elements during compilation. Use this enum (via :attr:`Element.layout_kind`)
    to determine whether an element is actually a layout container and, if so, which kind.
    """

    HorizontalLayout = 1
    """The element is a ``HorizontalLayout``."""

    VerticalLayout = 2
    """The element is a ``VerticalLayout``."""

    GridLayout = 3
    """The element is a ``GridLayout``."""

    FlexboxLayout = 4
    """The element is a flex box layout."""


@dataclass
class LogicalPosition:
    """
    A position represented in the coordinate space of logical pixels. That is the space before applying
    a display device specific scale factor.
    """

    x: float
    """The x coordinate."""

    y: float
    """The y coordinate."""


def _convert_logical_position(position: LogicalPosition) -> ProtoLogicalPosition:
    return ProtoLogicalPosition(x=position.x, y=position.y)


@dataclass
class PointerPressEvent:
    """A pointer was pressed."""

    position: LogicalPosition
    """The pointer position in logical coordinates."""

    button: PointerEventButton
    """The button that was pressed."""


def _convert_pointer_press_event(event: PointerPressEvent) -> ProtoPointerPressEvent:
    return ProtoPointerPressEvent(
        position=_convert_logical_position(event.position),
        button=_convert_button(event.button),
    )


@dataclass
class PointerReleaseEvent:
    """A pointer was released."""

    position: LogicalPosition
    """The pointer position in logical coordinates."""

    button: PointerEventButton
    """The button that was released."""


def _convert_pointer_release_event(
    event: PointerReleaseEvent,
) -> ProtoPointerReleaseEvent:
    return ProtoPointerReleaseEvent(
        position=_convert_logical_position(event.position),
        button=_convert_button(event.button),
    )


@dataclass
class PointerMoveEvent:
    """A pointer was moved."""

    position: LogicalPosition
    """The pointer position in logical coordinates."""


def _convert_pointer_move_event(event: PointerMoveEvent) -> ProtoPointerMoveEvent:
    return ProtoPointerMoveEvent(position=_convert_logical_position(event.position))


@dataclass
class PointerScrolledEvent:
    """The wheel button of a mouse was rotated to initiate scrolling."""

    position: LogicalPosition
    """The pointer position in logical coordinates."""

    delta_x: float
    """The amount of logical pixels to scroll in the horizontal direction."""

    delta_y: float
    """The amount of logical pixels to scroll in the vertical direction."""


def _convert_pointer_scrolled_event(
    event: PointerScrolledEvent,
) -> ProtoPointerScrolledEvent:
    return ProtoPointerScrolledEvent(
        position=_convert_logical_position(event.position),
        delta_x=event.delta_x,
        delta_y=event.delta_y,
    )


@dataclass
class PointerExitedEvent:
    """The pointer exited the window."""

    pass


@dataclass
class KeyPressedEvent:
    """A key was pressed."""

    text: str
    """The unicode representation of the key pressed."""


@dataclass
class KeyPressRepeatedEvent:
    """A key press was auto-repeated."""

    text: str
    """The unicode representation of the key pressed."""


@dataclass
class KeyReleasedEvent:
    """A key was released.."""

    text: str
    """The unicode representation of the key released."""


class ElementQuery:
    """
    Use ElementQuery to form a query into the tree of UI elements and then locate one or multiple
    matching elements.

    ElementQuery uses the builder pattern to concatenate criteria, such as searching for descendants,
    or matching elements only with a certain id.

    Construct an instance of this by calling {func}`Element.query_descendants`. Apply additional criterial on the returned `ElementQuery`
    and fetch results by either calling {func}`ElementQuery.find_first()` to collect just the first match or
    {func}`ElementQuery.find_all()` to collect all matches for the query.
    """

    def __init__(
        self, element: Element, instructions: typing.List[ProtoElementQueryInstruction]
    ):
        self.element = element
        self.instructions = instructions

    def match_descendants(self) -> ElementQuery:
        """Applies any subsequent matches to all descendants of the results of the query up to this point."""
        instructions = self.instructions.copy()
        instructions.append(ProtoElementQueryInstruction(match_descendants=True))
        return ElementQuery(self.element, instructions)

    def match_id(self, id: str) -> ElementQuery:
        """Include only elements in the results where {attr}`Element.id` is equal to the provided `id`."""
        instructions = self.instructions.copy()
        instructions.append(ProtoElementQueryInstruction(match_element_id=id))
        return ElementQuery(self.element, instructions)

    def match_type_name(self, type_name: str) -> ElementQuery:
        """Include only elements in the results where {attr}`Element.type_name` is equal to the provided `type_name`."""
        instructions = self.instructions.copy()
        instructions.append(
            ProtoElementQueryInstruction(match_element_type_name=type_name)
        )
        return ElementQuery(self.element, instructions)

    def match_inherits(self, type_name: str) -> ElementQuery:
        """Include only elements in the results where {attr}`Element.type_name` or {attr}`Element.bases` is contains to the provided `type_name`."""
        instructions = self.instructions.copy()
        instructions.append(
            ProtoElementQueryInstruction(match_element_type_name_or_base=type_name)
        )
        return ElementQuery(self.element, instructions)

    def match_accessible_role(self, role: AccessibleRole) -> ElementQuery:
        """Include only elements in the results where {attr}`Element.accessible_role` is equal to the provided `role`."""
        instructions = self.instructions.copy()
        instructions.append(
            ProtoElementQueryInstruction(match_element_accessible_role=role._proto_role)
        )
        return ElementQuery(self.element, instructions)

    def find_first(self) -> typing.Optional[Element]:
        """
        Runs the query and returns the first result; returns None if no element matches the selected
        criteria.
        """
        response = self.element.app._send_request(
            RequestToAUT(
                request_query_element_descendants=RequestQueryElementDescendants(
                    element_handle=self.element.handle,
                    query_stack=self.instructions,
                    find_all=False,
                )
            )
        )
        handles = response.element_query_response.element_handles
        return Element(self.element.app, handles[0]) if len(handles) > 0 else None

    def find_all(self) -> typing.List[Element]:
        """Runs the query and returns a list of all matching elements."""
        response = self.element.app._send_request(
            RequestToAUT(
                request_query_element_descendants=RequestQueryElementDescendants(
                    element_handle=self.element.handle,
                    query_stack=self.instructions,
                    find_all=True,
                )
            )
        )
        return [
            Element(self.element.app, handle)
            for handle in response.element_query_response.element_handles
        ]


class Element:
    """
    Element represents a weak reference to a UI element. Use {attr}`Window.root_element` to access an instance
    of the root element. Use {func}`Element.query_descendants` to initiate a query into the sub-tree of elements
    of this element.

    Use the accessible_* properties and functions to introspect and change state in UI elements in an appearance
    independent way. For more details about the different accessibilty properties, check out the [documentation in
    the Slint language](https://releases.slint.dev/latest/docs/slint/src/language/builtins/elements#accessibility).
    """

    def __init__(self, app, handle: Handle):
        self.app = app
        self.handle = handle

    @property
    def is_valid(self) -> bool:
        """
        Read-only property that is true if the element reference is still valid, i.e. if the element is still in the UI.
        """
        return not self.app._send_request(
            RequestToAUT(
                request_element_properties=RequestElementProperties(
                    element_handle=self.handle
                )
            )
        ).HasField("error")

    @property
    def id(self) -> str:
        """
        Read-only property that holds the element's qualified id.

        A qualified id consists of the name of the surrounding component as well as the provided local
        name, separate by a double colon.

        ```
        component PushButton {
            /* .. */
        }

        export component App {
            mybutton := PushButton { } // known as `App::mybutton`
            PushButton { } // no id
        }
        ```
        """
        return self._get_props().type_names_and_ids[0].id

    @property
    def type_name(self) -> str:
        """Read-only property that holds the element's type name."""
        return self._get_props().type_names_and_ids[0].type_name

    @property
    def bases(self) -> list[str]:
        """
        Read-only property that holds a list of the element's base types.

        ```
        component ButtonBase {
            /* .. */
        }

        component PushButton inherits ButtonBase {
            /* .. */
        }

        export component App {
           mybutton := PushButton { } // <-- bases is ["PushButton", "ButtonBase"]
        }
        ```
        """
        return [etnaid.type_name for etnaid in self._get_props().type_names_and_ids]

    @property
    def accessible_role(self) -> AccessibleRole:
        """Read-only property that holds the value of the `accessible-role` property in Slint, if present."""
        match self._get_props().accessible_role:
            case ProtoAccessibleRole.Unknown:
                return AccessibleRole.Unknown
            case ProtoAccessibleRole.Button:
                return AccessibleRole.Button
            case ProtoAccessibleRole.Checkbox:
                return AccessibleRole.Checkbox
            case ProtoAccessibleRole.Combobox:
                return AccessibleRole.Combobox
            case ProtoAccessibleRole.List:
                return AccessibleRole.List
            case ProtoAccessibleRole.Slider:
                return AccessibleRole.Slider
            case ProtoAccessibleRole.Spinbox:
                return AccessibleRole.Spinbox
            case ProtoAccessibleRole.Tab:
                return AccessibleRole.Tab
            case ProtoAccessibleRole.TabList:
                return AccessibleRole.TabList
            case ProtoAccessibleRole.Text:
                return AccessibleRole.Text
            case ProtoAccessibleRole.Table:
                return AccessibleRole.Table
            case ProtoAccessibleRole.Tree:
                return AccessibleRole.Tree
            case ProtoAccessibleRole.ProgressIndicator:
                return AccessibleRole.ProgressIndicator
            case ProtoAccessibleRole.TextInput:
                return AccessibleRole.TextInput
            case ProtoAccessibleRole.Switch:
                return AccessibleRole.Switch
            case ProtoAccessibleRole.TabPanel:
                return AccessibleRole.TabPanel
            case ProtoAccessibleRole.Groupbox:
                return AccessibleRole.Groupbox
            case ProtoAccessibleRole.Image:
                return AccessibleRole.Image
            case ProtoAccessibleRole.RadioButton:
                return AccessibleRole.RadioButton
            case ProtoAccessibleRole.RadioGroup:
                return AccessibleRole.RadioGroup
            case ProtoAccessibleRole.Banner:
                return AccessibleRole.Banner
            case ProtoAccessibleRole.Complementary:
                return AccessibleRole.Complementary
            case ProtoAccessibleRole.ContentInfo:
                return AccessibleRole.ContentInfo
            case ProtoAccessibleRole.Form:
                return AccessibleRole.Form
            case ProtoAccessibleRole.Main:
                return AccessibleRole.Main
            case ProtoAccessibleRole.Navigation:
                return AccessibleRole.Navigation
            case ProtoAccessibleRole.Region:
                return AccessibleRole.Region
            case ProtoAccessibleRole.Search:
                return AccessibleRole.Search
            case _ as unknown:
                return AccessibleRole.Unknown

    @property
    def accessible_label(self) -> str:
        """Read-only property that holds the value of the `accessible-label` property in Slint, if present."""
        return self._get_props().accessible_label

    @property
    def accessible_value(self) -> str:
        """Read-write property that holds the value of the `accessible-value` property in Slint."""
        return self._get_props().accessible_value

    @accessible_value.setter
    def accessible_value(self, value):
        self.app._send_request(
            RequestToAUT(
                request_set_element_accessible_value=RequestSetElementAccessibleValue(
                    element_handle=self.handle, value=value
                )
            )
        )

    @property
    def accessible_value_maximum(self) -> float:
        """Read-only property that holds the value of the `accessible-value-maximum` property in Slint, if present."""
        return self._get_props().accessible_value_maximum

    @property
    def accessible_value_minimum(self) -> float:
        """Read-only property that holds the value of the `accessible-value-minimum` property in Slint, if present."""
        return self._get_props().accessible_value_minimum

    @property
    def accessible_value_step(self) -> float:
        """Read-only property that holds the value of the `accessible-value-step` property in Slint, if present."""
        return self._get_props().accessible_value_step

    @property
    def accessible_description(self) -> str:
        """Read-only property that holds the value of the `accessible-description` property in Slint, if present."""
        return self._get_props().accessible_description

    @property
    def accessible_checked(self) -> bool:
        """Read-only property that holds the value of the `accessible-checked` property in Slint, if present."""
        return self._get_props().accessible_checked

    @property
    def accessible_checkable(self) -> bool:
        """Read-only property that holds the value of the `accessible-checkable` property in Slint, if present."""
        return self._get_props().accessible_checkable

    @property
    def accessible_placeholder_text(self) -> str:
        """Read-write property that holds the value of the `accessible-placeholder-text` property in Slint."""
        return self._get_props().accessible_placeholder_text

    @property
    def accessible_enabled(self) -> bool:
        """Read-write property that holds the value of the `accessible-enabled` property in Slint."""
        return self._get_props().accessible_enabled

    @property
    def accessible_read_only(self) -> bool:
        """Read-write property that holds the value of the `accessible-read-only` property in Slint."""
        return self._get_props().accessible_read_only

    @property
    def layout_kind(self) -> typing.Optional[LayoutKind]:
        """
        Read-only property that returns the layout kind if this element is a layout container,
        or ``None`` if it is not a layout element.

        Layout elements such as ``HorizontalLayout``, ``VerticalLayout``, and ``GridLayout`` are
        lowered to ``Rectangle`` during compilation. This property lets you distinguish layout
        containers from plain rectangles.
        """
        match self._get_props().layout_kind:
            case ProtoLayoutKind.HorizontalLayout:
                return LayoutKind.HorizontalLayout
            case ProtoLayoutKind.VerticalLayout:
                return LayoutKind.VerticalLayout
            case ProtoLayoutKind.GridLayout:
                return LayoutKind.GridLayout
            case ProtoLayoutKind.FlexboxLayout:
                return LayoutKind.FlexboxLayout
            case _:
                return None

    @property
    def size(self) -> typing.Tuple[float, float]:
        """Read-only property that holds size of the element in logical pixels, as a tuple of width and height."""
        sz = self._get_props().size
        return (sz.width, sz.height)

    @property
    def absolute_position(self) -> typing.Tuple[float, float]:
        """Read-only property that holds the absolute position of the element in logical pixels within the window, as a tuple of x and y."""
        position = self._get_props().absolute_position
        return (position.x, position.y)

    @property
    def computed_opacity(self) -> float:
        """Read-only property that holds the opacity that is applied when rendering this
        element. This is the product of the opacity property multipled with any opacity
        specified by parent elements. Returns zero if the element is not valid."""
        return self._get_props().computed_opacity

    def invoke_accessible_default_action(self):
        """
        Invokes the default accessible action on the element. For example a `MyButton` element might declare
        an accessible default action that simulates a click, as in the following example:

        ```
        component MyButton {
            // ...
            callback clicked();
            in property <string> text;

            TouchArea {
                clicked => { root.clicked() }
            }
            accessible-role: button;
            accessible-label: self.text;
            accessible-action-default => { self.clicked(); }
        }
        ```
        """
        self.app._send_request(
            RequestToAUT(
                request_invoke_element_accessibility_action=RequestInvokeElementAccessibilityAction(
                    element_handle=self.handle,
                    action=ElementAccessibilityAction.Default_,
                )
            )
        )

    def invoke_accessible_increment_action(self):
        """
        Invokes the element's `accessible-action-increment` callback, if declared. On widgets such as spinboxes, this
        typically increments the value.
        """
        self.app._send_request(
            RequestToAUT(
                request_invoke_element_accessibility_action=RequestInvokeElementAccessibilityAction(
                    element_handle=self.handle,
                    action=ElementAccessibilityAction.Increment,
                )
            )
        )

    def invoke_accessible_decrement_action(self):
        """
        Invokes the element's `accessible-action-decrement` callback, if declared. On widgets such as spinboxes, this
        typically increments the value.
        """
        self.app._send_request(
            RequestToAUT(
                request_invoke_element_accessibility_action=RequestInvokeElementAccessibilityAction(
                    element_handle=self.handle,
                    action=ElementAccessibilityAction.Decrement,
                )
            )
        )

    def invoke_accessible_expand_action(self):
        """
        Invokes the element's `accessible-action-expand` callback, if declared. On widgets such as spinboxes, this
        typically decrements the value.
        """
        self.app._send_request(
            RequestToAUT(
                request_invoke_element_accessibility_action=RequestInvokeElementAccessibilityAction(
                    element_handle=self.handle,
                    action=ElementAccessibilityAction.Expand,
                )
            )
        )

    def single_click(self, button: PointerEventButton):
        """
        Simulates a single mouse click sequence on the element's center.
        """
        self._click(ClickAction.SingleClick, button)

    def double_click(self, button: PointerEventButton):
        """
        Simulates a mouse double click sequence on the element's center.
        """
        self._click(ClickAction.DoubleClick, button)

    def query_descendants(self) -> ElementQuery:
        """
        Creates a new element query into all sub-elements of this elements. This includes the children
        as well as the children of the children, and so forth. Use {class}`ElementQuery`
        to refine your query. When your query is ready, run it by calling either {func}`ElementQuery.find_first`
        or {func}`ElementQuery.find_all`.
        """
        return ElementQuery(self, [])

    def _click(self, action: ClickAction, button: PointerEventButton):
        proto_button = _convert_button(button)
        self.app._send_request(
            RequestToAUT(
                request_element_click=RequestElementClick(
                    element_handle=self.handle, action=action, button=proto_button
                )
            )
        )

    def _get_props(self) -> ElementPropertiesResponse:
        return self.app._send_request(
            RequestToAUT(
                request_element_properties=RequestElementProperties(
                    element_handle=self.handle
                )
            )
        ).element_properties


class Window:
    """
    Window represents a weak reference a slint::Window in your application.

    Use the properties to inspect the window state and use {attr}`Window.root_element`
    in combination with {func}`Element.query_descendants` to locate UI elements.
    """

    def __init__(self, app, handle: Handle):
        self.app = app
        self.handle = handle

    @property
    def is_minimized(self) -> bool:
        """Read-only property that holds the minimize state of the Window."""
        return getattr(self._get_props(), "is_minimized", False)

    @property
    def is_maximized(self) -> bool:
        """Read-only property that holds the maximize state of the Window."""
        return getattr(self._get_props(), "is_maximized", False)

    @property
    def is_fullscreen(self) -> bool:
        """Read-only property that returns true if the window is shown fullscreen."""
        return getattr(self._get_props(), "is_fullscreen", False)

    @property
    def size(self) -> typing.Tuple[int, int]:
        """Read-only property that returns size of the Window in physical pixels, as a tuple of width and height."""
        sz = self._get_props().size
        return (sz.width, sz.height)

    @property
    def position(self) -> typing.Tuple[int, int]:
        """Read-only property that returns position of the Window on the screen in physical pixels, as a tuple of x and y."""
        position = self._get_props().position
        return (position.x, position.y)

    @property
    def root_element(self) -> Element:
        """Read-only property that returns the Window's root element"""
        return Element(self.app, self._get_props().root_element_handle)

    def find_elements_by_id(self, id: str) -> list[Element]:
        # """
        # This function searches through the entire tree of elements of this window and looks for
        # elements by their id. The id is a qualified string consisting of the name of the component
        # and the assigned name within the component. In the following examples, the first Button
        # has the id "MyView::submit-button" and the second button "App::close":
        #
        # ```
        # component MyView {
        #    submit-button := Button {}
        # }
        #
        # export component App {
        #     VerticalLayout {
        #         close := Button {}
        #     }
        # }
        # ```
        # """
        return self.root_element.query_descendants().match_id(id).find_all()

    def grab_window_as_png(self) -> bytes:
        """
        Grabs a screenshot of the window and returns it as PNG encoded image.
        """
        return self.app._send_request(
            RequestToAUT(
                request_take_snapshot=RequestTakeSnapshot(window_handle=self.handle)
            )
        ).take_snapshot_response.window_contents_as_encoded_image

    def grab_window_with_mime_type(self, image_mime_type: str) -> bytes:
        """
        Grabs a screenshot of the window and returns it as image encoded in the supplied format.
        For this to succeed, make sure that the application is used with Slint where support for
        the desired image format is enabled.

        For Rust applications, `image/png` and `image/jpeg` are enabled by default. Additional formats
        can be enabled via the [image crate](https://crates.io/crates/image) as well as the
        [`image-default-formats`](https://docs.slint.dev/latest/docs/rust/slint/docs/cargo_features/) feature flag.

        For C++, JavaScript, and Python applications, by default `image/bmp`, `image/gif`, `image/vnd.radiance`,
        `image/x-icon`, `image/jpeg`, `image/x-exr`, `image/png`, `image/x-portable-bitmap`, `image/x-qoi`,
        `image/x-targa`, `image/tiff` and `image/webp` are supported.
        """
        return self.app._send_request(
            RequestToAUT(
                request_take_snapshot=RequestTakeSnapshot(
                    window_handle=self.handle, image_mime_type=image_mime_type
                )
            )
        ).take_snapshot_response.window_contents_as_encoded_image

    def dispatch_event(
        self,
        event: PointerPressEvent
        | PointerReleaseEvent
        | PointerMoveEvent
        | PointerScrolledEvent
        | PointerExitedEvent
        | KeyPressedEvent
        | KeyPressRepeatedEvent
        | KeyReleasedEvent,
    ):
        """
        Dispatches one of the possible event types to the window. Use this for low-level control to simulate user input.
        """

        def send_event(event: ProtoWindowEvent):
            return self.app._send_request(
                RequestToAUT(
                    request_dispatch_window_event=RequestDispatchWindowEvent(
                        window_handle=self.handle, event=event
                    )
                )
            )

        match event:
            case PointerPressEvent(position, button):
                send_event(
                    ProtoWindowEvent(
                        pointer_pressed=_convert_pointer_press_event(event)
                    )
                )
            case PointerReleaseEvent(position, button):
                send_event(
                    ProtoWindowEvent(
                        pointer_released=_convert_pointer_release_event(event)
                    )
                )
            case PointerMoveEvent(position):
                send_event(
                    ProtoWindowEvent(pointer_moved=_convert_pointer_move_event(event))
                )
            case PointerScrolledEvent(position, delta_x, delta_y):
                send_event(
                    ProtoWindowEvent(
                        pointer_scrolled=_convert_pointer_scrolled_event(event)
                    )
                )
            case PointerExitedEvent():
                send_event(ProtoWindowEvent(pointer_exited=ProtoPointerExitedEvent()))
            case KeyPressedEvent(text):
                send_event(
                    ProtoWindowEvent(key_pressed=ProtoKeyPressedEvent(text=text))
                )
            case KeyPressRepeatedEvent(text):
                send_event(
                    ProtoWindowEvent(
                        key_press_repeated=ProtoKeyPressRepeatedEvent(text=text)
                    )
                )
            case KeyReleasedEvent(text):
                send_event(
                    ProtoWindowEvent(key_released=ProtoKeyReleasedEvent(text=text))
                )

    def drag_and_drop(
        self,
        start: LogicalPosition,
        end: LogicalPosition,
        button: PointerEventButton = PointerEventButton.Left,
        steps: int = 10,
    ) -> None:
        """
        Simulates a drag-and-drop interaction by dispatching a pointer press at ``start``,
        a sequence of ``steps`` interpolated pointer moves ending at ``end``, and finally a
        pointer release at ``end``.

        Use ``steps`` to control granularity of the motion. The last move event lands exactly
        on ``end`` so handlers that read the pointer position on release see the expected
        location.

        - start: Start position in logical pixels.
        - end: End position in logical pixels.
        - button: The button to press during the drag. Defaults to the left button.
        - steps: Number of interpolated pointer move events between ``start`` and ``end``.
          Must be at least 1.
        """
        if steps < 1:
            raise ValueError("drag_and_drop() requires steps >= 1")

        self.dispatch_event(PointerPressEvent(position=start, button=button))
        for i in range(1, steps + 1):
            t = i / steps
            position = LogicalPosition(
                x=start.x + (end.x - start.x) * t,
                y=start.y + (end.y - start.y) * t,
            )
            self.dispatch_event(PointerMoveEvent(position=position))
        self.dispatch_event(PointerReleaseEvent(position=end, button=button))

    def _get_props(self) -> WindowPropertiesResponse:
        return self.app._send_request(
            RequestToAUT(
                request_window_properties=RequestWindowProperties(
                    window_handle=self.handle
                )
            )
        ).window_properties


class Application(contextlib.AbstractContextManager):
    """
    Use the Application object to launch your application and establish a connection with the Slint UI testing framework.

    Construct the Application with the following parameters:

    - args: The elements of the command line to lauch. This will be passed to `subprocess.Popen`.
    - ssh_destination: Set to a `user@hostname` like string to launch the application on a remote host via SSH.
      The Application takes care of setting up the entire ssh command line and assumes that the program that's
      the first element of `args` exists on the remote machine. If `None`, the application is launched locally
      without SSH.
    - env: A dictionary of optional environment variables as key/value pairs to set when launching.
    - launch_timeout: A value in seconds that Application will wait for the program to launch.

    Use Application with Python's [with statement](https://docs.python.org/3/reference/compound_stmts.html#with) to
    ensure propery lifecycle management of the sub-process and the network connection from within Python.

    ```python
    import slint_testing

    with slint_testing.Application(["/path/to/app"]) as aut:
       # ...

    # After leaving the above block, the application is terminated.
    ```
    """

    def __init__(
        self,
        args: typing.List[str],
        ssh_destination: str | None = None,
        env: dict[str, str] | None = None,
        launch_timeout: float = 20,
    ) -> None:
        super().__init__()
        self.test_server_socket = socket.create_server(
            ("127.0.0.1", 0), family=socket.AF_INET
        )
        # Attempt to disable the Nagle algorithm to favor faster packet exchange (latency)
        # over throughput.
        self.test_server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        self.args = args
        self.ssh_destination = ssh_destination
        self.env = env
        self.launch_timeout = launch_timeout

    def __enter__(self) -> "Application":
        ip, port = self.test_server_socket.getsockname()

        args = self.args

        if self.ssh_destination:
            cmd_args = ["SLINT_TEST_SERVER=localhost:8091"]

            if self.env:
                cmd_args.extend([f"{k}={v}" for k, v in self.env.items()])

            cmd_args.extend(args)

            ssh_args = [
                "ssh",
                "-R",
                f"8091:{ip}:{port}",
                self.ssh_destination,
                shlex.join(cmd_args),
            ]
            args = ssh_args
            env = os.environ.copy()
        else:
            env = self.env or os.environ.copy()
            env["SLINT_TEST_SERVER"] = f"localhost:{port}"

        self.process = subprocess.Popen(args, env=env)

        self.process.__enter__()

        r, w, x = select.select([self.test_server_socket], [], [], self.launch_timeout)
        if len(r) == 0:
            raise Exception(
                "Timeout (10 seconds) waiting for test application to connect"
            )
        self.aut_connection, addr = self.test_server_socket.accept()

        return self

    def __exit__(self, exc_type, exc_value, traceback) -> bool | None:
        self.aut_connection.close()
        self.test_server_socket.close()

        self.process.terminate()
        self.process.__exit__(exc_type, exc_value, traceback)

        return None

    def _read_aut_socket(self, size: int) -> bytes:
        buffer = b""
        while size > 0:
            partial = self.aut_connection.recv(size)
            if not partial:
                raise Exception("AUT connection closed unexpectedly")
            buffer += partial
            size -= len(partial)
        return buffer

    def _send_request(self, request: RequestToAUT) -> AUTResponse:
        # Write message size as big-endian 4-byte unsigned int first
        size_header = struct.pack(">I", request.ByteSize())
        self.aut_connection.sendall(size_header)
        self.aut_connection.sendall(request.SerializeToString())
        response_size_header = self._read_aut_socket(4)
        (response_size,) = struct.unpack(">I", response_size_header)
        resp = AUTResponse()
        resp.ParseFromString(self._read_aut_socket(response_size))
        return resp

    @property
    def first_window(self) -> typing.Optional[Window]:
        """
        Read-only property that holds a reference to the first visible Slint Window.
        Use this as the entry point to obtain UI elements and test their state and interaction.
        """
        response = self._send_request(
            RequestToAUT(request_window_list=RequestWindowListMessage())
        )
        return Window(self, response.window_list.window_handles[0])

    @property
    def windows(self) -> typing.List[Window]:
        """
        Read-only property that returns a list of all visible Slint windows.
        Pick an element from the returned list and use this as the entry point to obtain UI elements
        and test their state and interaction.
        """
        response = self._send_request(
            RequestToAUT(request_window_list=RequestWindowListMessage())
        )
        return [Window(self, handle) for handle in response.window_list.window_handles]

    def wait(self, timeout=None) -> int | None:
        """
        Wait until the AUT exits. Returns the exit code. Use this
        when you instructed the process to terminate through your own
        means.
        """
        return self.process.wait(timeout)
