from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import (
    ClassVar as _ClassVar,
    Iterable as _Iterable,
    Mapping as _Mapping,
    Optional as _Optional,
    Union as _Union,
)

DESCRIPTOR: _descriptor.FileDescriptor

class ElementAccessibilityAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Default_: _ClassVar[ElementAccessibilityAction]
    Increment: _ClassVar[ElementAccessibilityAction]
    Decrement: _ClassVar[ElementAccessibilityAction]
    Expand: _ClassVar[ElementAccessibilityAction]

class PointerEventButton(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Left: _ClassVar[PointerEventButton]
    Right: _ClassVar[PointerEventButton]
    Middle: _ClassVar[PointerEventButton]

class ClickAction(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    SingleClick: _ClassVar[ClickAction]
    DoubleClick: _ClassVar[ClickAction]

class LayoutKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    NotALayout: _ClassVar[LayoutKind]
    HorizontalLayout: _ClassVar[LayoutKind]
    VerticalLayout: _ClassVar[LayoutKind]
    GridLayout: _ClassVar[LayoutKind]
    FlexboxLayout: _ClassVar[LayoutKind]

class AccessibleRole(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    Unknown: _ClassVar[AccessibleRole]
    Button: _ClassVar[AccessibleRole]
    Checkbox: _ClassVar[AccessibleRole]
    Combobox: _ClassVar[AccessibleRole]
    List: _ClassVar[AccessibleRole]
    Slider: _ClassVar[AccessibleRole]
    Spinbox: _ClassVar[AccessibleRole]
    Tab: _ClassVar[AccessibleRole]
    TabList: _ClassVar[AccessibleRole]
    Text: _ClassVar[AccessibleRole]
    Table: _ClassVar[AccessibleRole]
    Tree: _ClassVar[AccessibleRole]
    ProgressIndicator: _ClassVar[AccessibleRole]
    TextInput: _ClassVar[AccessibleRole]
    Switch: _ClassVar[AccessibleRole]
    ListItem: _ClassVar[AccessibleRole]
    TabPanel: _ClassVar[AccessibleRole]
    Groupbox: _ClassVar[AccessibleRole]
    Image: _ClassVar[AccessibleRole]
    RadioButton: _ClassVar[AccessibleRole]

Default_: ElementAccessibilityAction
Increment: ElementAccessibilityAction
Decrement: ElementAccessibilityAction
Expand: ElementAccessibilityAction
Left: PointerEventButton
Right: PointerEventButton
Middle: PointerEventButton
SingleClick: ClickAction
DoubleClick: ClickAction
NotALayout: LayoutKind
HorizontalLayout: LayoutKind
VerticalLayout: LayoutKind
GridLayout: LayoutKind
FlexboxLayout: LayoutKind
Unknown: AccessibleRole
Button: AccessibleRole
Checkbox: AccessibleRole
Combobox: AccessibleRole
List: AccessibleRole
Slider: AccessibleRole
Spinbox: AccessibleRole
Tab: AccessibleRole
TabList: AccessibleRole
Text: AccessibleRole
Table: AccessibleRole
Tree: AccessibleRole
ProgressIndicator: AccessibleRole
TextInput: AccessibleRole
Switch: AccessibleRole
ListItem: AccessibleRole
TabPanel: AccessibleRole
Groupbox: AccessibleRole
Image: AccessibleRole
RadioButton: AccessibleRole

class Handle(_message.Message):
    __slots__ = ("index", "generation")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    index: int
    generation: int
    def __init__(
        self, index: _Optional[int] = ..., generation: _Optional[int] = ...
    ) -> None: ...

class PointerPressEvent(_message.Message):
    __slots__ = ("position", "button")
    POSITION_FIELD_NUMBER: _ClassVar[int]
    BUTTON_FIELD_NUMBER: _ClassVar[int]
    position: LogicalPosition
    button: PointerEventButton
    def __init__(
        self,
        position: _Optional[_Union[LogicalPosition, _Mapping]] = ...,
        button: _Optional[_Union[PointerEventButton, str]] = ...,
    ) -> None: ...

class PointerReleaseEvent(_message.Message):
    __slots__ = ("position", "button")
    POSITION_FIELD_NUMBER: _ClassVar[int]
    BUTTON_FIELD_NUMBER: _ClassVar[int]
    position: LogicalPosition
    button: PointerEventButton
    def __init__(
        self,
        position: _Optional[_Union[LogicalPosition, _Mapping]] = ...,
        button: _Optional[_Union[PointerEventButton, str]] = ...,
    ) -> None: ...

class PointerMoveEvent(_message.Message):
    __slots__ = ("position",)
    POSITION_FIELD_NUMBER: _ClassVar[int]
    position: LogicalPosition
    def __init__(
        self, position: _Optional[_Union[LogicalPosition, _Mapping]] = ...
    ) -> None: ...

class PointerScrolledEvent(_message.Message):
    __slots__ = ("position", "delta_x", "delta_y")
    POSITION_FIELD_NUMBER: _ClassVar[int]
    DELTA_X_FIELD_NUMBER: _ClassVar[int]
    DELTA_Y_FIELD_NUMBER: _ClassVar[int]
    position: LogicalPosition
    delta_x: float
    delta_y: float
    def __init__(
        self,
        position: _Optional[_Union[LogicalPosition, _Mapping]] = ...,
        delta_x: _Optional[float] = ...,
        delta_y: _Optional[float] = ...,
    ) -> None: ...

class PointerExitedEvent(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class KeyPressedEvent(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class KeyPressRepeatedEvent(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class KeyReleasedEvent(_message.Message):
    __slots__ = ("text",)
    TEXT_FIELD_NUMBER: _ClassVar[int]
    text: str
    def __init__(self, text: _Optional[str] = ...) -> None: ...

class WindowEvent(_message.Message):
    __slots__ = (
        "pointer_pressed",
        "pointer_released",
        "pointer_moved",
        "pointer_scrolled",
        "pointer_exited",
        "key_pressed",
        "key_press_repeated",
        "key_released",
    )
    POINTER_PRESSED_FIELD_NUMBER: _ClassVar[int]
    POINTER_RELEASED_FIELD_NUMBER: _ClassVar[int]
    POINTER_MOVED_FIELD_NUMBER: _ClassVar[int]
    POINTER_SCROLLED_FIELD_NUMBER: _ClassVar[int]
    POINTER_EXITED_FIELD_NUMBER: _ClassVar[int]
    KEY_PRESSED_FIELD_NUMBER: _ClassVar[int]
    KEY_PRESS_REPEATED_FIELD_NUMBER: _ClassVar[int]
    KEY_RELEASED_FIELD_NUMBER: _ClassVar[int]
    pointer_pressed: PointerPressEvent
    pointer_released: PointerReleaseEvent
    pointer_moved: PointerMoveEvent
    pointer_scrolled: PointerScrolledEvent
    pointer_exited: PointerExitedEvent
    key_pressed: KeyPressedEvent
    key_press_repeated: KeyPressRepeatedEvent
    key_released: KeyReleasedEvent
    def __init__(
        self,
        pointer_pressed: _Optional[_Union[PointerPressEvent, _Mapping]] = ...,
        pointer_released: _Optional[_Union[PointerReleaseEvent, _Mapping]] = ...,
        pointer_moved: _Optional[_Union[PointerMoveEvent, _Mapping]] = ...,
        pointer_scrolled: _Optional[_Union[PointerScrolledEvent, _Mapping]] = ...,
        pointer_exited: _Optional[_Union[PointerExitedEvent, _Mapping]] = ...,
        key_pressed: _Optional[_Union[KeyPressedEvent, _Mapping]] = ...,
        key_press_repeated: _Optional[_Union[KeyPressRepeatedEvent, _Mapping]] = ...,
        key_released: _Optional[_Union[KeyReleasedEvent, _Mapping]] = ...,
    ) -> None: ...

class ElementQueryInstruction(_message.Message):
    __slots__ = (
        "match_descendants",
        "match_element_id",
        "match_element_type_name",
        "match_element_type_name_or_base",
        "match_element_accessible_role",
    )
    MATCH_DESCENDANTS_FIELD_NUMBER: _ClassVar[int]
    MATCH_ELEMENT_ID_FIELD_NUMBER: _ClassVar[int]
    MATCH_ELEMENT_TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    MATCH_ELEMENT_TYPE_NAME_OR_BASE_FIELD_NUMBER: _ClassVar[int]
    MATCH_ELEMENT_ACCESSIBLE_ROLE_FIELD_NUMBER: _ClassVar[int]
    match_descendants: bool
    match_element_id: str
    match_element_type_name: str
    match_element_type_name_or_base: str
    match_element_accessible_role: AccessibleRole
    def __init__(
        self,
        match_descendants: bool = ...,
        match_element_id: _Optional[str] = ...,
        match_element_type_name: _Optional[str] = ...,
        match_element_type_name_or_base: _Optional[str] = ...,
        match_element_accessible_role: _Optional[_Union[AccessibleRole, str]] = ...,
    ) -> None: ...

class RequestWindowListMessage(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class RequestWindowProperties(_message.Message):
    __slots__ = ("window_handle",)
    WINDOW_HANDLE_FIELD_NUMBER: _ClassVar[int]
    window_handle: Handle
    def __init__(
        self, window_handle: _Optional[_Union[Handle, _Mapping]] = ...
    ) -> None: ...

class RequestFindElementsById(_message.Message):
    __slots__ = ("window_handle", "elements_id")
    WINDOW_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ELEMENTS_ID_FIELD_NUMBER: _ClassVar[int]
    window_handle: Handle
    elements_id: str
    def __init__(
        self,
        window_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        elements_id: _Optional[str] = ...,
    ) -> None: ...

class RequestElementProperties(_message.Message):
    __slots__ = ("element_handle",)
    ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    element_handle: Handle
    def __init__(
        self, element_handle: _Optional[_Union[Handle, _Mapping]] = ...
    ) -> None: ...

class RequestInvokeElementAccessibilityAction(_message.Message):
    __slots__ = ("element_handle", "action")
    ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    element_handle: Handle
    action: ElementAccessibilityAction
    def __init__(
        self,
        element_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        action: _Optional[_Union[ElementAccessibilityAction, str]] = ...,
    ) -> None: ...

class RequestSetElementAccessibleValue(_message.Message):
    __slots__ = ("element_handle", "value")
    ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    VALUE_FIELD_NUMBER: _ClassVar[int]
    element_handle: Handle
    value: str
    def __init__(
        self,
        element_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        value: _Optional[str] = ...,
    ) -> None: ...

class RequestTakeSnapshot(_message.Message):
    __slots__ = ("window_handle", "image_mime_type")
    WINDOW_HANDLE_FIELD_NUMBER: _ClassVar[int]
    IMAGE_MIME_TYPE_FIELD_NUMBER: _ClassVar[int]
    window_handle: Handle
    image_mime_type: str
    def __init__(
        self,
        window_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        image_mime_type: _Optional[str] = ...,
    ) -> None: ...

class RequestElementClick(_message.Message):
    __slots__ = ("element_handle", "action", "button")
    ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    ACTION_FIELD_NUMBER: _ClassVar[int]
    BUTTON_FIELD_NUMBER: _ClassVar[int]
    element_handle: Handle
    action: ClickAction
    button: PointerEventButton
    def __init__(
        self,
        element_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        action: _Optional[_Union[ClickAction, str]] = ...,
        button: _Optional[_Union[PointerEventButton, str]] = ...,
    ) -> None: ...

class RequestDispatchWindowEvent(_message.Message):
    __slots__ = ("window_handle", "event")
    WINDOW_HANDLE_FIELD_NUMBER: _ClassVar[int]
    EVENT_FIELD_NUMBER: _ClassVar[int]
    window_handle: Handle
    event: WindowEvent
    def __init__(
        self,
        window_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        event: _Optional[_Union[WindowEvent, _Mapping]] = ...,
    ) -> None: ...

class RequestQueryElementDescendants(_message.Message):
    __slots__ = ("element_handle", "query_stack", "find_all")
    ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    QUERY_STACK_FIELD_NUMBER: _ClassVar[int]
    FIND_ALL_FIELD_NUMBER: _ClassVar[int]
    element_handle: Handle
    query_stack: _containers.RepeatedCompositeFieldContainer[ElementQueryInstruction]
    find_all: bool
    def __init__(
        self,
        element_handle: _Optional[_Union[Handle, _Mapping]] = ...,
        query_stack: _Optional[
            _Iterable[_Union[ElementQueryInstruction, _Mapping]]
        ] = ...,
        find_all: bool = ...,
    ) -> None: ...

class RequestToAUT(_message.Message):
    __slots__ = (
        "request_window_list",
        "request_window_properties",
        "request_find_elements_by_id",
        "request_element_properties",
        "request_invoke_element_accessibility_action",
        "request_set_element_accessible_value",
        "request_take_snapshot",
        "request_element_click",
        "request_dispatch_window_event",
        "request_query_element_descendants",
    )
    REQUEST_WINDOW_LIST_FIELD_NUMBER: _ClassVar[int]
    REQUEST_WINDOW_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    REQUEST_FIND_ELEMENTS_BY_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ELEMENT_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    REQUEST_INVOKE_ELEMENT_ACCESSIBILITY_ACTION_FIELD_NUMBER: _ClassVar[int]
    REQUEST_SET_ELEMENT_ACCESSIBLE_VALUE_FIELD_NUMBER: _ClassVar[int]
    REQUEST_TAKE_SNAPSHOT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ELEMENT_CLICK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_DISPATCH_WINDOW_EVENT_FIELD_NUMBER: _ClassVar[int]
    REQUEST_QUERY_ELEMENT_DESCENDANTS_FIELD_NUMBER: _ClassVar[int]
    request_window_list: RequestWindowListMessage
    request_window_properties: RequestWindowProperties
    request_find_elements_by_id: RequestFindElementsById
    request_element_properties: RequestElementProperties
    request_invoke_element_accessibility_action: RequestInvokeElementAccessibilityAction
    request_set_element_accessible_value: RequestSetElementAccessibleValue
    request_take_snapshot: RequestTakeSnapshot
    request_element_click: RequestElementClick
    request_dispatch_window_event: RequestDispatchWindowEvent
    request_query_element_descendants: RequestQueryElementDescendants
    def __init__(
        self,
        request_window_list: _Optional[
            _Union[RequestWindowListMessage, _Mapping]
        ] = ...,
        request_window_properties: _Optional[
            _Union[RequestWindowProperties, _Mapping]
        ] = ...,
        request_find_elements_by_id: _Optional[
            _Union[RequestFindElementsById, _Mapping]
        ] = ...,
        request_element_properties: _Optional[
            _Union[RequestElementProperties, _Mapping]
        ] = ...,
        request_invoke_element_accessibility_action: _Optional[
            _Union[RequestInvokeElementAccessibilityAction, _Mapping]
        ] = ...,
        request_set_element_accessible_value: _Optional[
            _Union[RequestSetElementAccessibleValue, _Mapping]
        ] = ...,
        request_take_snapshot: _Optional[_Union[RequestTakeSnapshot, _Mapping]] = ...,
        request_element_click: _Optional[_Union[RequestElementClick, _Mapping]] = ...,
        request_dispatch_window_event: _Optional[
            _Union[RequestDispatchWindowEvent, _Mapping]
        ] = ...,
        request_query_element_descendants: _Optional[
            _Union[RequestQueryElementDescendants, _Mapping]
        ] = ...,
    ) -> None: ...

class ErrorResponse(_message.Message):
    __slots__ = ("message",)
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    message: str
    def __init__(self, message: _Optional[str] = ...) -> None: ...

class WindowListResponse(_message.Message):
    __slots__ = ("window_handles",)
    WINDOW_HANDLES_FIELD_NUMBER: _ClassVar[int]
    window_handles: _containers.RepeatedCompositeFieldContainer[Handle]
    def __init__(
        self, window_handles: _Optional[_Iterable[_Union[Handle, _Mapping]]] = ...
    ) -> None: ...

class PhysicalSize(_message.Message):
    __slots__ = ("width", "height")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    width: int
    height: int
    def __init__(
        self, width: _Optional[int] = ..., height: _Optional[int] = ...
    ) -> None: ...

class PhysicalPosition(_message.Message):
    __slots__ = ("x", "y")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    x: int
    y: int
    def __init__(self, x: _Optional[int] = ..., y: _Optional[int] = ...) -> None: ...

class LogicalSize(_message.Message):
    __slots__ = ("width", "height")
    WIDTH_FIELD_NUMBER: _ClassVar[int]
    HEIGHT_FIELD_NUMBER: _ClassVar[int]
    width: float
    height: float
    def __init__(
        self, width: _Optional[float] = ..., height: _Optional[float] = ...
    ) -> None: ...

class LogicalPosition(_message.Message):
    __slots__ = ("x", "y")
    X_FIELD_NUMBER: _ClassVar[int]
    Y_FIELD_NUMBER: _ClassVar[int]
    x: float
    y: float
    def __init__(
        self, x: _Optional[float] = ..., y: _Optional[float] = ...
    ) -> None: ...

class WindowPropertiesResponse(_message.Message):
    __slots__ = (
        "is_fullscreen",
        "is_maximized",
        "is_minimized",
        "size",
        "position",
        "root_element_handle",
    )
    IS_FULLSCREEN_FIELD_NUMBER: _ClassVar[int]
    IS_MAXIMIZED_FIELD_NUMBER: _ClassVar[int]
    IS_MINIMIZED_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    POSITION_FIELD_NUMBER: _ClassVar[int]
    ROOT_ELEMENT_HANDLE_FIELD_NUMBER: _ClassVar[int]
    is_fullscreen: bool
    is_maximized: bool
    is_minimized: bool
    size: PhysicalSize
    position: PhysicalPosition
    root_element_handle: Handle
    def __init__(
        self,
        is_fullscreen: bool = ...,
        is_maximized: bool = ...,
        is_minimized: bool = ...,
        size: _Optional[_Union[PhysicalSize, _Mapping]] = ...,
        position: _Optional[_Union[PhysicalPosition, _Mapping]] = ...,
        root_element_handle: _Optional[_Union[Handle, _Mapping]] = ...,
    ) -> None: ...

class ElementsResponse(_message.Message):
    __slots__ = ("element_handles",)
    ELEMENT_HANDLES_FIELD_NUMBER: _ClassVar[int]
    element_handles: _containers.RepeatedCompositeFieldContainer[Handle]
    def __init__(
        self, element_handles: _Optional[_Iterable[_Union[Handle, _Mapping]]] = ...
    ) -> None: ...

class ElementTypeNameAndId(_message.Message):
    __slots__ = ("type_name", "id")
    TYPE_NAME_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    type_name: str
    id: str
    def __init__(
        self, type_name: _Optional[str] = ..., id: _Optional[str] = ...
    ) -> None: ...

class ElementPropertiesResponse(_message.Message):
    __slots__ = (
        "type_names_and_ids",
        "accessible_label",
        "accessible_value",
        "accessible_value_maximum",
        "accessible_value_minimum",
        "accessible_value_step",
        "accessible_description",
        "accessible_checked",
        "accessible_checkable",
        "size",
        "absolute_position",
        "accessible_role",
        "computed_opacity",
        "accessible_placeholder_text",
        "accessible_enabled",
        "accessible_read_only",
        "layout_kind",
    )
    TYPE_NAMES_AND_IDS_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_LABEL_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_VALUE_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_VALUE_MAXIMUM_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_VALUE_MINIMUM_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_VALUE_STEP_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_CHECKED_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_CHECKABLE_FIELD_NUMBER: _ClassVar[int]
    SIZE_FIELD_NUMBER: _ClassVar[int]
    ABSOLUTE_POSITION_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_ROLE_FIELD_NUMBER: _ClassVar[int]
    COMPUTED_OPACITY_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_PLACEHOLDER_TEXT_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_ENABLED_FIELD_NUMBER: _ClassVar[int]
    ACCESSIBLE_READ_ONLY_FIELD_NUMBER: _ClassVar[int]
    LAYOUT_KIND_FIELD_NUMBER: _ClassVar[int]
    type_names_and_ids: _containers.RepeatedCompositeFieldContainer[
        ElementTypeNameAndId
    ]
    accessible_label: str
    accessible_value: str
    accessible_value_maximum: float
    accessible_value_minimum: float
    accessible_value_step: float
    accessible_description: str
    accessible_checked: bool
    accessible_checkable: bool
    size: LogicalSize
    absolute_position: LogicalPosition
    accessible_role: AccessibleRole
    computed_opacity: float
    accessible_placeholder_text: str
    accessible_enabled: bool
    accessible_read_only: bool
    layout_kind: LayoutKind
    def __init__(
        self,
        type_names_and_ids: _Optional[
            _Iterable[_Union[ElementTypeNameAndId, _Mapping]]
        ] = ...,
        accessible_label: _Optional[str] = ...,
        accessible_value: _Optional[str] = ...,
        accessible_value_maximum: _Optional[float] = ...,
        accessible_value_minimum: _Optional[float] = ...,
        accessible_value_step: _Optional[float] = ...,
        accessible_description: _Optional[str] = ...,
        accessible_checked: bool = ...,
        accessible_checkable: bool = ...,
        size: _Optional[_Union[LogicalSize, _Mapping]] = ...,
        absolute_position: _Optional[_Union[LogicalPosition, _Mapping]] = ...,
        accessible_role: _Optional[_Union[AccessibleRole, str]] = ...,
        computed_opacity: _Optional[float] = ...,
        accessible_placeholder_text: _Optional[str] = ...,
        accessible_enabled: bool = ...,
        accessible_read_only: bool = ...,
        layout_kind: _Optional[_Union[LayoutKind, str]] = ...,
    ) -> None: ...

class InvokeElementAccessibilityActionResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SetElementAccessibleValueResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TakeSnapshotResponse(_message.Message):
    __slots__ = ("window_contents_as_encoded_image",)
    WINDOW_CONTENTS_AS_ENCODED_IMAGE_FIELD_NUMBER: _ClassVar[int]
    window_contents_as_encoded_image: bytes
    def __init__(
        self, window_contents_as_encoded_image: _Optional[bytes] = ...
    ) -> None: ...

class ElementClickResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DispatchWindowEventResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ElementQueryResponse(_message.Message):
    __slots__ = ("element_handles",)
    ELEMENT_HANDLES_FIELD_NUMBER: _ClassVar[int]
    element_handles: _containers.RepeatedCompositeFieldContainer[Handle]
    def __init__(
        self, element_handles: _Optional[_Iterable[_Union[Handle, _Mapping]]] = ...
    ) -> None: ...

class AUTResponse(_message.Message):
    __slots__ = (
        "error",
        "window_list",
        "window_properties",
        "elements",
        "element_properties",
        "invoke_element_accessibility_action_response",
        "set_element_accessible_value_response",
        "take_snapshot_response",
        "element_click_response",
        "dispatch_window_event_response",
        "element_query_response",
    )
    ERROR_FIELD_NUMBER: _ClassVar[int]
    WINDOW_LIST_FIELD_NUMBER: _ClassVar[int]
    WINDOW_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    ELEMENTS_FIELD_NUMBER: _ClassVar[int]
    ELEMENT_PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    INVOKE_ELEMENT_ACCESSIBILITY_ACTION_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    SET_ELEMENT_ACCESSIBLE_VALUE_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    TAKE_SNAPSHOT_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    ELEMENT_CLICK_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    DISPATCH_WINDOW_EVENT_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    ELEMENT_QUERY_RESPONSE_FIELD_NUMBER: _ClassVar[int]
    error: ErrorResponse
    window_list: WindowListResponse
    window_properties: WindowPropertiesResponse
    elements: ElementsResponse
    element_properties: ElementPropertiesResponse
    invoke_element_accessibility_action_response: (
        InvokeElementAccessibilityActionResponse
    )
    set_element_accessible_value_response: SetElementAccessibleValueResponse
    take_snapshot_response: TakeSnapshotResponse
    element_click_response: ElementClickResponse
    dispatch_window_event_response: DispatchWindowEventResponse
    element_query_response: ElementQueryResponse
    def __init__(
        self,
        error: _Optional[_Union[ErrorResponse, _Mapping]] = ...,
        window_list: _Optional[_Union[WindowListResponse, _Mapping]] = ...,
        window_properties: _Optional[_Union[WindowPropertiesResponse, _Mapping]] = ...,
        elements: _Optional[_Union[ElementsResponse, _Mapping]] = ...,
        element_properties: _Optional[
            _Union[ElementPropertiesResponse, _Mapping]
        ] = ...,
        invoke_element_accessibility_action_response: _Optional[
            _Union[InvokeElementAccessibilityActionResponse, _Mapping]
        ] = ...,
        set_element_accessible_value_response: _Optional[
            _Union[SetElementAccessibleValueResponse, _Mapping]
        ] = ...,
        take_snapshot_response: _Optional[_Union[TakeSnapshotResponse, _Mapping]] = ...,
        element_click_response: _Optional[_Union[ElementClickResponse, _Mapping]] = ...,
        dispatch_window_event_response: _Optional[
            _Union[DispatchWindowEventResponse, _Mapping]
        ] = ...,
        element_query_response: _Optional[_Union[ElementQueryResponse, _Mapping]] = ...,
    ) -> None: ...
